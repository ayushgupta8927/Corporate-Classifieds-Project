﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OfferMicroservice.Models
{
    public class LikeData
    {
        public string Category { get; set; }

        public string Details { get; set; }

    }
}
