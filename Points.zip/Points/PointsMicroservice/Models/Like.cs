﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PointsMicroservice.Models
{
    public class Like
    {
      //  public int LikeId { get; set; }

        public int OfferId { get; set; }

        public DateTime LikeDate{ get; set; }

        //public int NoOfLikes { get; set; }
    }
}
