import React, { useState } from 'react';
// import "react-table-6/react-table.css";
import {  Col, Form, Row, FormGroup, Button } from 'reactstrap';
// import Navbar from '../Components/Navbar/Navbar';
import {AiFillLike} from 'react-icons/ai'


function ViewMostLikedOffers() {
    const ProductsByLike = [];
    const employeeID = React.createRef();
    // const details = React.createRef();
    // const offerId = React.createRef();
    // const offerId = React.createRef();
    
    // const employeeId = React.createRef();
    const [getResult, setGetResult] = useState(null);
    const [boolean, setboolean] = useState(false);
    async function OnSubmit() {
        // const OfferId = offerId.current.value;
        const EmployeeID = employeeID.current.value;

        // const EmployeeId = employeeId.current.value;
        // console.log(OfferId);
        await fetch(`https://localhost:5001/api/Employee/ViewMostLikedOffers/${EmployeeID}`)
            .then(response => response.json())
            .then(
                (result) => {
                    // ProductsByLike.push(result);
                    console.log(result)
                    setGetResult([...result]);
                    setboolean(true);
                },
                (error) => {
                    alert("Some Error Occured During Fetching");
                }
            )
    };
  return (
    
    <div>

    <div>
        <h4 align="center">Offer List</h4>
        <Form>
            <Col>
                <FormGroup row>
                    <label htmlFor="EmployeeID">EmployeeID</label>
                    <Col sm={10}>
                        <input type="text" name="EmployeeID" ref={employeeID} placeholder="EmployeeID" />

                    </Col>
                </FormGroup>
            </Col>
            <Col>
                <FormGroup row>
                    <Col sm={5}>
                    </Col>
                    <Col sm={1}>
                        <button type="button" onClick={() => OnSubmit()} className="btn btn-success">Submit</button>
                    </Col>
                    <Col sm={1}>
                        <button type="button" className="btn btn-danger">Cancel</button>{' '}
                    </Col>
                    <Col sm={5}>
                    </Col>
                </FormGroup>
            </Col>
        </Form>
    </div>
    <div>   
     {boolean &&
                    getResult.map((product) => {
                        return (
                            <>
                                <div className=' box col-lg-3 col-sm-6 col-md-3 mb-4'>
                                    {/* <div class="card h-100 text-center p-4" key={product.id}> */}
                                    <div class="card h-100 text-center p-4" key={product.employeeId}>
                                        <img src={"img.png"} class="card-img-top" alt={product.employeeName} height="300px" />
                                        <div class="card-body">
                                            <h5 class="card-title mb-0">{product.employeeName}</h5>
                                            <h6 class="card-title mb-0 text-success">{product.employeeId}</h6>

                                            <p class="card-text"><i className="like btn btn-primary btn-outline-light"><AiFillLike />{product.likes}</i>Posted by <b>Emp Id:&nbsp;{product.employeeId}</b></p>
                                            {/* <a  href="#" class="btn btn-primary">View Details</a> */}
                                        </div>
                                    </div>
                                </div>
                            </>
                        )
                    })}
                    {// <div>
                    //     <h4 align="center">Business Property List</h4>
                    //     <table className="table table-striped" style={{ marginTop: 10, border: 2 }}>
                    //         <thead>
                    //             <tr>
                    //                 <th>Offer Id</th>
                    //                 <th>details</th>
                    //                 <th>Likes</th>
                    //                  <th>Status</th>
                    //                 <th>Category</th>
                    //                 <th>Opened Date</th>
                    //                 {/*<th>CostOfTheAsset</th>
                    //                 <th>SalvageValue</th>
                    //                 <th>UsefulLifeOfTheAsset</th>
                    //                 <th>PropertyValue</th> */}
                    //             </tr>
                    //         </thead>
                    //         <tbody>
                    //             {getResult.map(bp =>
                    //                 <tr key={bp.offerId}>
                    //                     <td>{bp.offerId}</td>
                    //                     <td>{bp.details}</td>
                    //                     <td>{bp.likes}</td>
                    //                     <td>{bp.status}</td>
                    //                     <td>{bp.category}</td>
                    //                     <td>{bp.openedDate}</td>
                    //                      {/* <td>{bp.buildingAge}</td>
                    //                     <td>{bp.costOfTheAsset}</td>
                    //                     <td>{bp.salvageValue}</td>
                    //                     <td>{bp.usefulLifeOfTheAsset}</td>
                    //                     <td>{bp.propertyValue}</td> */}
                    //                 </tr>
                    //             )}
                    //         </tbody>
                    //     </table>
                    // </div>g
            } 
            </div> 
    </div >
  );
}

export default ViewMostLikedOffers;