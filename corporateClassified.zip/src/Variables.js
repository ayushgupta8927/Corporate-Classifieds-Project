export const variables={
    API_URL:"https://localhost:5001/api/",
    PHOTO_URL:"https://localhost:5001/Photos/"
}